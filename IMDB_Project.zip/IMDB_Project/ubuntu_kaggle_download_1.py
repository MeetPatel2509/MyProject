import kaggle
import time
kaggle.api.authenticate()
start=time.time()
kaggle.api.dataset_download_files('ashirwadsangwan/imdb-dataset', path='/home/ubuntu/new_kaggle_dataset', unzip=True)
end=time.time()
print("time take to download data:  "+ str(end-start))
