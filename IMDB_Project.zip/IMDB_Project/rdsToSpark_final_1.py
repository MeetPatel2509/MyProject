from pyspark.sql import SparkSession
from config_1 import props
from pyspark.sql.types import *
from pyspark.sql.functions import *
import time

spark = SparkSession.builder.config("spark.jars", "mysql-connector-j-8.0.31.jar") \
.master("yarn").appName("PySpark_Rds_To_S3").getOrCreate()

start=time.time()

print("Reading data from RDS")   
title_ratings = spark.read.format("jdbc").\
    options(
            url="jdbc:mysql://" + props.rds_host + ":" + str(props.rds_port) + "/" + props.rds_database,
            driver="com.mysql.jdbc.Driver",
            dbtable="title_ratings",
            user=props.user_name,
            password=props.user_password). \
load()

title_basics = spark.read.format("jdbc").\
    options(
            url="jdbc:mysql://" + props.rds_host + ":" + str(props.rds_port)+ "/" + props.rds_database, 
            driver="com.mysql.jdbc.Driver",
            dbtable="title_basics",
            user=props.user_name,
            password=props.user_password).\
load()
title_basics.printSchema() 

title_akas = spark.read.format("jdbc").\
    options(
            url="jdbc:mysql://" + props.rds_host + ":" + str(props.rds_port)  + "/" + props.rds_database,
            driver="com.mysql.jdbc.Driver",
            dbtable="title_akas",
            user=props.user_name,
            password=props.user_password).\
load()
title_akas.printSchema()
name_basics = spark.read.format("jdbc").\
    options(
            url="jdbc:mysql://" + props.rds_host + ":" + str(props.rds_port) + "/" + props.rds_database,
            driver="com.mysql.jdbc.Driver",
            dbtable="name_basics",
            user=props.user_name,
            password=props.user_password).\
load()
name_basics.printSchema()
title_principals = spark.read.format("jdbc").\
    options(
            url="jdbc:mysql://" + props.rds_host + ":" + str(props.rds_port) + "/" + props.rds_database,
            driver="com.mysql.jdbc.Driver",
            dbtable="title_principals",
            user=props.user_name,
            password=props.user_password).\
load()
title_principals.printSchema()

print("Data loaded from RDS to df.") 
print("Data read")

### type casting columns ---------
print("Starting transformations")

name_basics = name_basics.withColumn("birthYear",col("birthYear").cast(IntegerType())).withColumn("deathYear",col("deathYear").cast(IntegerType())) 
    
title_akas = title_akas.withColumn("isOriginalTitle",col("isOriginalTitle").cast(BooleanType())) 

title_basics = title_basics.withColumn("isAdult",col("isAdult").cast(BooleanType())) \
                          .withColumn("startYear",col("startYear").cast(IntegerType())) \
                          .withColumn("endYear",col("endYear").cast(IntegerType())) \
                          .withColumn("runtimeMinutes",col("runtimeMinutes").cast(IntegerType()))
                          
##############################################################################

### data cleaning --------------

## title basic --------------
print("starting basics")
print(title_basics.rdd.getNumPartitions())
title_basics = title_basics.repartition(5)
print("title_basics repartitioned")
title_basics =  title_basics.na.fill(value=2200,subset=["endYear"])
title_basics.dropDuplicates()
title_basics = title_basics.withColumn("titleType",trim(title_basics.titleType))
title_basics = title_basics.withColumn("primaryTitle",trim(title_basics.primaryTitle))
title_basics = title_basics.withColumn("originalTitle",trim(title_basics.originalTitle))

temp_title_basic = title_basics.filter(title_basics.startYear.isNull())  #temp table for null values
title_basics = title_basics.filter(~(title_basics.startYear.isNull()))  
title_basics = title_basics.filter(~(title_basics.titleType.isNull()))
title_basics = title_basics.filter((title_basics.startYear > 0) & (title_basics.endYear > 0))
title_basics = title_basics.filter(title_basics.startYear < title_basics.endYear)
title_basics = title_basics.filter(~(title_basics.primaryTitle.isNull() | isnan(title_basics.primaryTitle) \
                                | title_basics.originalTitle.isNull() | isnan(title_basics.originalTitle)))

print("basics transformation done")
print("writing basics to s3")
title_basics.coalesce(1).write.mode('overwrite').option("header",True).partitionBy('titleType').parquet(props.bucket_path+"output/cleansedEmrData/title_basics")
print("basics done")

print("principals")
title_principals.write.mode('overwrite').option("header",True).parquet(props.bucket_path+"output/cleansedEmrData/title_principals")
print("principals done")
## ratings ----------------

title_ratings = title_ratings.filter((title_ratings.averageRating > 0) & (title_ratings.numVotes > 0))
title_ratings.dropDuplicates()
print("writing ratings to s3")
title_ratings.write.mode('overwrite').option("header",True).parquet(props.bucket_path+"output/cleansedEmrData/title_ratings")

## title akas -------------
print("akas started")
title_akas = title_akas.repartition(8)
print("akas partitioned ")
title_akas = title_akas.dropDuplicates()
title_akas = title_akas.replace(r'\N', None)

title_akas = title_akas.filter(~(title_akas.types.isNull()))
title_akas = title_akas.filter((~(title_akas.types == "original")))

title_akas = title_akas.drop(title_akas.isOriginalTitle)
title_akas = title_akas.drop(title_akas.attributes)
title_akas = title_akas.drop(title_akas.language) 

print("akas done")
print("writing akas to s3")

title_akas.coalesce(1).write.mode('overwrite').option("header",True).parquet(props.bucket_path+"output/cleansedEmrData/title_akas")
print("akas done")

## joining tables ::::::
print("joins started")
df_basics_ratings = title_basics.join(broadcast(title_ratings), title_basics.tconst == title_ratings.tconst). \
    select(title_basics.tconst, title_basics.titleType, title_basics.primaryTitle, title_basics.originalTitle, \
        title_basics.startYear,title_basics.endYear, title_ratings.averageRating,title_ratings.numVotes)

df_basics_akas = title_basics.join(title_akas, title_akas.titleId == title_basics.tconst,"inner"). \
    select(title_basics.tconst, title_basics.titleType, title_basics.primaryTitle, title_basics.originalTitle, \
        title_basics.startYear,title_basics.endYear,title_akas.types)

df_basics_akas_ratings = title_basics.join(title_akas,title_akas.titleId == title_basics.tconst,"inner"). \
                                      join(broadcast(title_ratings),title_ratings.tconst == title_basics.tconst). \
                                    select(title_basics.tconst, title_basics.titleType, title_basics.primaryTitle, title_basics.originalTitle, \
        title_basics.startYear,title_basics.endYear, title_ratings.averageRating,title_ratings.numVotes,title_akas.types)
    
print("joins done")   
####  WRITING TABLE TO S3
print("writing joins to s3")

df_basics_ratings.coalesce(1).write.mode('overwrite').option("header",True).partitionBy('titleType').parquet(props.bucket_path+"output/JoinedData/basic_rating")
df_basics_akas.coalesce(1).write.mode('overwrite').option("header",True).partitionBy('titleType').parquet(props.bucket_path+"output/JoinedData/basic_akas")
df_basics_akas_ratings.coalesce(1).write.mode('overwrite').option("header",True).partitionBy('titleType').parquet(props.bucket_path+"output/JoinedData/basic_akas_rating")

print("joins written to S3")

print("repartition done to name basics and writing to s3 now")
name_basics.write.mode('overwrite').option("header",True).parquet(props.bucket_path+"output/cleansedEmrData/name_basics")

print("name basics written to s3")

print("JOB FINISHED")
end=time.time()
print("Time taken for job:  " + str(end-start))

