from airflow.models import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime
from airflow.operators.bash import BashOperator
# from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.models import Variable
from airflow.providers.amazon.aws.operators.emr import EmrCreateJobFlowOperator
from airflow.providers.amazon.aws.operators.emr import EmrAddStepsOperator
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor
aws_access_key = Variable.get('aws_access_key')
aws_secret_key = Variable.get('aws_secret_key')


default_args = {
    'owner': 'Sukhpreet',
    'depends_on_past': False,
    'retries': 0
}

SPARK_STEPS_1 = [
            {
                'Name': 'Setup Debugging',
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': ['state-pusher-script']
                }
            },
            {
                'Name': 'copy files',
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': ['aws', 's3', 'sync', 's3://sukhimdbdemo/scripts/' , '/home/hadoop/']
                }
            },
            {
                'Name': 'copy jar',
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': ['aws', 's3', 'cp', 's3://sukhimdbdemo/mysql-connector-j-8.0.31.jar' , '/home/hadoop/']
                }
            },
            {
                'Name': 'Spark',
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': ['spark-submit','--jars','/home/hadoop/mysql-connector-j-8.0.31.jar',\
                        '--driver-memory','12g','--executor-memory','80g','--num-executors','12',\
                            '--executor-cores','5','/home/hadoop/rdsToSpark_final_1.py']
                }
            }
]
JOB_FLOW_OVERRIDES_1 = {
    'Name' : 'sukhimdbemr',
    'ReleaseLabel' : 'emr-6.8.0',
    'LogUri' : 's3://aws-logs-223865032204-us-east-1/elasticmapreduce/',
    'Applications':[
            {
                'Name': 'Spark'
            },
        ],
        'Instances' : {
            'InstanceFleets': [
                {
                    'Name': "Master",
                    'InstanceFleetType': 'MASTER',
                    'TargetOnDemandCapacity': 1,
                    'InstanceTypeConfigs': [
                        {
                            'InstanceType': 'm5.xlarge',
                        },
                ]
                },
                {
                    'Name': "Slave",
                    'InstanceFleetType':'CORE',
                    'TargetOnDemandCapacity': 4,
                    'InstanceTypeConfigs': [
                        {
                            'InstanceType': 'm5.4xlarge',
                        },
                    ],
                }
            ],
            'Ec2KeyName': 'EC2KeyKT',
            'KeepJobFlowAliveWhenNoSteps': False,
            'TerminationProtected': False,
            'Ec2SubnetId': 'subnet-0c7c9fac224e9a177',
        },
        'VisibleToAllUsers':True,
        'JobFlowRole':'EMR_EC2_DefaultRole',
        'ServiceRole':'EMR_DefaultRole',
        'EbsRootVolumeSize': 32,
        'StepConcurrencyLevel': 2,
        'Tags':[
            {
                'Key': 'BU',
                'Value': 'DE',
            },
            {
                'Key': 'Owner',
                'Value': 'Sukhpreet',
            },
        ],

}

with DAG(
    dag_id="sukh_imdb_final_dag",
    default_args=default_args,
    # Dag should start from 18 Nov 2022.
    start_date=datetime(2022, 11, 18),
    schedule='30 10 * 12 0', #minute hour day month week
    catchup=False
) as dag:

    Begin = EmptyOperator(
        task_id='start',
        dag=dag
    )

    Kaggle_Download = BashOperator(
        task_id="Download_files_from_kaggle",
        bash_command='python3 /home/ubuntu/newscripts/ubuntu_kaggle_download_1.py',
    )
    
    Send_Data_To_RDS = BashOperator(
        task_id="Write_to_RDS",
        bash_command='python3 /home/ubuntu/newscripts/load_to_rds_1.py',
    )
    
    Create_Bucket = BashOperator(
        task_id = 'Create_Bucket',
        bash_command='aws s3api create-bucket --acl public-read-write --bucket sukhimdbdemo --region us-east-1; exit 0;',
    )
    
    Move_Scripts_To_S3_1 = BashOperator(
        task_id = 'Move_Script_To_S3_1',
        bash_command = 'aws s3 sync /home/ubuntu/newscripts/ s3://sukhimdbdemo/scripts/; exit 0;',
    )
    
    Move_Jar_To_S3 = BashOperator(
        task_id = 'Move_Jar_To_S3',
        bash_command = 'aws s3 cp /home/ubuntu/mysql-connector-j-8.0.31.jar s3://sukhimdbdemo/; exit 0;',
    )
    
    Create_EMR_Cluster = EmrCreateJobFlowOperator(
        task_id='Creating_Cluster_1',
        job_flow_overrides=JOB_FLOW_OVERRIDES_1
    )
    
    Tasks_Adder_1 = EmrAddStepsOperator(
        task_id='Add_Tasks_1',
        job_flow_id="{{ task_instance.xcom_pull(task_ids='Creating_Cluster_1', key='return_value') }}",
        aws_conn_id='aws_default',
        steps=SPARK_STEPS_1,
    )

    Tasks_Checker = EmrStepSensor(
        task_id='Checking_tasks',
        job_flow_id="{{ task_instance.xcom_pull('Creating_Cluster_1', key='return_value') }}",
        step_id="{{ task_instance.xcom_pull(task_ids='Add_Tasks_1', key='return_value')[3] }}",
        aws_conn_id='aws_default',
    )

    # glue_job_step = GlueJobOperator(
    #     task_id = "glue_job_step",
    #     job_name = "imdbRDSdataJob",
    #     job_desc = f"triggering glue job {'job_name'}",
    #     region_name = "us-east-1",
    #     iam_role_name = "AWSGlueRole",
    #     num_of_dpus = 2,
    #     dag = dag
    # )

##dpu=data processing unit 4cpu 16gb memory
    Finish = EmptyOperator(
        task_id='end',
        dag=dag
    )


    Begin >> Kaggle_Download >> Send_Data_To_RDS >> Create_EMR_Cluster >> Tasks_Adder_1 >> Tasks_Checker >> Finish
    Begin >> Create_Bucket >> [Move_Scripts_To_S3_1,Move_Jar_To_S3]>> Create_EMR_Cluster
    
