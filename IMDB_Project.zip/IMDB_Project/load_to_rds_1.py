import mysql.connector 
import os
import glob
import time


conn = mysql.connector.connect(host="sukhimdb.cdyarwjuez7j.us-east-1.rds.amazonaws.com", port=3306,\
        user="admin", passwd="12345678",allow_local_infile=True,database="imdb_project")
     
_path = "/home/ubuntu/new_kaggle_dataset/"
_path2 = "/home/ubuntu/new_kaggle_dataset/*/*.tsv"

files = os.listdir(_path)
tlist = []
for i in range(0,len(files)):
        newl = files[i].split(".")
        tlist.append((newl[0] + "_" + newl[1]))

print(tlist)

for (fname1,tname1) in zip(glob.glob(_path2,recursive=True),tlist):
        print(fname1,"   ",tname1)

    
                        
try:
        conn.commit()
        cur = conn.cursor()
        print('Creating table.')
        
        cur.execute("create table if not exists name_basics (nconst varchar(15), primaryName varchar(120), birthYear int, deathYear int, primaryProfession varchar(80), knownForTitles varchar(80));")
        
        cur.execute("create table if not exists title_akas (titleId varchar(15),ordering int, title varchar(900), region varchar(8), language varchar(8), types varchar(30), attributes varchar(80), isOriginalTitle tinyint);")
        
        cur.execute("create table if not exists title_basics (tconst varchar(15),titleType varchar(20), primaryTitle varchar(450),originalTitle varchar(450),isAdult int,startYear varchar(5), endYear varchar(5),runtimeMinutes int,genres varchar(40));")
        
        cur.execute("create table if not exists title_principals (tconst varchar(15),ordering int, nconst varchar(15),category varchar(30),job varchar(350),characters varchar(1400));")
        
        cur.execute("create table if not exists title_ratings (tconst varchar(15),averageRating float, numVotes int);")
        
        for (fname1,tname1) in zip(glob.glob(_path2,recursive=True),tlist):
            print(f'\n Inserting data into table {tname1}\n')
            st = time.time()
            qry1=f"LOAD DATA LOCAL INFILE '{fname1}' INTO TABLE {tname1} FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' IGNORE 1 ROWS;"
            cur.execute(qry1)
            end=time.time()
            print("time taken:  ",str(end-st))
            conn.commit()
            print(f'Data saved successfully in {tname1}')
        
        print("ALl FILES WRITTEN...")
except Exception as e:
        print(f'error | {e}')
        
conn.close
